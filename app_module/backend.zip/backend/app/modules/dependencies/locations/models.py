from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime


# -------------------
# BASE STRUCTURE
# -------------------

class LocationBase(BaseModel):

    # Physical layout
    zone: str                 # QA / STORAGE / SHIPPING
    aisle: str                # A / B / C
    rack: str                 # 01 / 02 / 03
    level: str                # 1 / 2 / 3
    position: str             # L / R / FRONT

    description: Optional[str] = ""

    # Capacity per rack position
    capacity: Optional[int] = None


# -------------------
# CREATE
# -------------------

class LocationCreate(LocationBase):
    pass


# -------------------
# UPDATE (PATCH SAFE)
# -------------------

class LocationUpdate(BaseModel):

    zone: Optional[str] = None
    aisle: Optional[str] = None
    rack: Optional[str] = None
    level: Optional[str] = None
    position: Optional[str] = None

    description: Optional[str] = None
    capacity: Optional[int] = None

    active: Optional[bool] = None


# -------------------
# OUTPUT MODEL
# -------------------

class LocationOut(LocationBase):

    id: str

    id_plant: str

    # Flags
    active: bool

    # Metadata
    created_at: datetime
    updated_at: datetime
