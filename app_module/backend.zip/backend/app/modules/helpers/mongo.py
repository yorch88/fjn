from bson import ObjectId

def normalize_mongo_doc(doc: dict):
    for k, v in doc.items():
        if isinstance(v, ObjectId):
            doc[k] = str(v)

        elif isinstance(v, list):
            for item in v:
                if isinstance(item, dict):
                    normalize_mongo_doc(item)

        elif isinstance(v, dict):
            normalize_mongo_doc(v)

    return doc
