from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime 

class Ticket(BaseModel):
    id: Optional[str] = None
    title: str

class TicketCreate(BaseModel):
    title: str
    description: str
    priority: str = "medium"
    requester: str
    # 👇 El cliente NO manda estos campos
    # id_plant y created_at los pone el backend


class TicketInDB(BaseModel):
    id: str
    title: str
    description: str
    priority: str
    requester: str
    id_plant: str
    created_at: datetime
