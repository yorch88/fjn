from fastapi import APIRouter, Depends, Request

from app.core.security import get_current_user
from app.shared.utils import ensure_same_plant
from .service import list_tickets, create_ticket, create_ticket_for_plant
from .models import TicketCreate, TicketInDB

router = APIRouter(tags=["Tickets"], dependencies=[Depends(get_current_user)])

@router.get("/", dependencies=[Depends(get_current_user)])
async def list_tickets():
    return await get_all_tickets()

@router.post("/", response_model=TicketInDB, dependencies=[Depends(get_current_user)])
async def create_ticket(request: Request, body: TicketCreate):
    user = request.state.user          # <- seteado por tu middleware
    plant_id = user["id_plant"]
    return await create_ticket_for_plant(body, plant_id)