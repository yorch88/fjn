

from datetime import datetime
from ...core.db import get_db
from .models import TicketCreate, TicketInDB
from bson import ObjectId

async def list_tickets(user_plant: str):
    db = get_db()

    cursor = db.tickets.find({
        "id_plant": user_plant   # 👈 filtro obligatorio
    })

    return await cursor.to_list(None)

async def create_ticket(ticket):
    db = await get_db()
    await db.tickets.insert_one(ticket)
    return {"message": "Ticket created"}

async def save_ticket(data):
    db = get_db()
    doc = data.model_dump()
    await db.tickets.insert_one(doc)
    return doc

async def create_ticket_for_plant(data: TicketCreate, plant_id: str) -> TicketInDB:
    db = await get_db()

    doc = data.model_dump()
    doc["id_plant"] = plant_id
    doc["created_at"] = datetime.utcnow()

    result = await db.tickets.insert_one(doc)
    doc_id = str(result.inserted_id)

    return TicketInDB(id=doc_id, **doc)