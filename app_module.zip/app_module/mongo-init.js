db = db.getSiblingDB("support_prod");

db.createUser({
  user: "support_app",
  pwd: "support_app_pwd",
  roles: [
    {
      role: "readWrite",
      db: "support_prod"
    }
  ]
});
