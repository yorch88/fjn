import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import "./index.css";

import Home from "./pages/Home.jsx";
import Login from "./modules/auth/Login.jsx";
import RequireAuth from "./modules/auth/RequireAuth.jsx";

import InventoryReports from "./modules/inventory/pages/InventoryReports.jsx";
import InventoryCreate from "./modules/inventory/pages/InventoryCreate.jsx";
import InventoryUpdate from "./modules/inventory/pages/InventoryUpdate.jsx";
import InventorySilverHours from "./modules/inventory/pages/InventorySilverHours";
import LocationsList from "./modules/locations/pages/LocationsList.jsx";
import LocationCreate from "./modules/locations/pages/LocationCreate.jsx";
import TasksCreate from "./modules/tasks/pages/TasksCreate.jsx";
import TasksReports from "./modules/tasks/pages/TasksReports.jsx";
import TasksDetail from "./modules/tasks/pages/TasksDetail.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        {/* MENU PRINCIPAL */}
        <Route path="/" element={<Home />} />

        {/* LOGIN */}
        <Route path="/login" element={<Login />} />

        {/* INVENTORY */}
        <Route
          path="/inventory"
          element={
            <RequireAuth>
              <InventoryReports />
            </RequireAuth>
          }
        />
        <Route
          path="/inventory/new"
          element={
            <RequireAuth>
              <InventoryCreate />
            </RequireAuth>
          }
        />
        <Route
          path="/inventory/:id/edit"
          element={
            <RequireAuth>
              <InventoryUpdate />
            </RequireAuth>
          }
        />
        <Route
          path="/inventory/silver-hours"
          element={
            <RequireAuth>
              <InventorySilverHours />
            </RequireAuth>
          }
        />
        <Route
          path="/task/create"
          element={
            <RequireAuth>
              <TasksCreate />
            </RequireAuth>
          }
        />
        <Route
          path="/task/all"
          element={
            <RequireAuth>
              <TasksReports />
            </RequireAuth>
          }
        />
        <Route
          path="/tasks/:id"
          element={
            <RequireAuth>
              <TasksDetail />
            </RequireAuth>
          }
        />
        <Route path="/locations" element={<LocationsList />} />
        <Route path="/locations/create" element={<LocationCreate />} />
      </Routes>  
    </BrowserRouter>
  </React.StrictMode>
);
